// This is a no-op electron module, a placeholder because
// the pkg `got` requires it, but it's never actually
// used
