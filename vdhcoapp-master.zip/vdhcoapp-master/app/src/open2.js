// This is a no-op open module for Node 10.
export default function open() {
}
